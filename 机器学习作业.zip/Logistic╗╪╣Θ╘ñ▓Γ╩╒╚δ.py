# -*- coding: utf-8 -*-
"""
Created on Mon Jul 15 19:58:24 2019

@author: 李瀚哲
"""
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer#特征提取
from sklearn.linear_model.logistic import LogisticRegression
from sklearn.model_selection import train_test_split,cross_val_score


df = pd.read_csv('spam_train.csv')
# 空值填0
df = df.fillna(0)
# (4000, 59)
array = np.array(df)
# (4000, 57)
x = array[:, 1:-1]
#print(x)
# scale
x[-1] /= np.mean(x[-1])
x[-2] /= np.mean(x[-2])
# (4000, )
y = array[:, -1]
# 划分训练集与验证集
x_train, x_val = x[0:3500, :], x[3500:4000, :]
y_train, y_val = y[0:3500], y[3500:4000]
#print(x_val)
classifier = LogisticRegression()
classifier.fit(x_train, y_train)
predictions = classifier.predict(x_val)
scores = cross_val_score(classifier, x_train, y_train, cv=5)
for i, prediction in enumerate(predictions[-500:,]):
    print('第%d个人是否成功: %d' % (i+3501,prediction))

print('准确率：',np.mean(scores))

