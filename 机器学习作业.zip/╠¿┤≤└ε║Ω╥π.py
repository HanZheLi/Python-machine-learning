# -*- coding: utf-8 -*-
"""
Created on Mon Jul 15 11:31:17 2019

@author: 李瀚哲
"""

import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
def dataProcess(df):
    x_list, y_list = [], []
    # df替换指定元素，将空数据填充为0
    df = df.replace(['NR'], [0.0])
    # astype() 转换array中元素数据类型
    array = np.array(df).astype(float)
    # 将数据集拆分为多个数据帧
    for i in range(0, 4320, 18):
        for j in range(24-9):
            mat = array[i:i+18, j:j+9]#将0~17行的前9个数据都入mat
            label = array[i+9, j+9] # 第10行是PM2.5
            x_list.append(mat)
            y_list.append(label)
    x = np.array(x_list)
    y = np.array(y_list)
    
    return x, y, array

df = pd.read_csv('train(1).csv', usecols=range(3,27))
model = LinearRegression()
x,y,x_y= dataProcess(df)
#x[i]表示是3600项中的第几项，x[i][j]是一个列表
#print(x[0][9])


for i in range(3600):
    y=x[i][9]
    j=i%15      
    X=[[j],[j+1],[j+2],[j+3],[j+4],[j+5],[j+6],[j+7],[j+8]]
    #print(X)
    model.fit(X,x[i][9])
    #print(X)
    print("预测后一个小时的PM2.5值为：%.2f" % model.predict([[j]])[0])
